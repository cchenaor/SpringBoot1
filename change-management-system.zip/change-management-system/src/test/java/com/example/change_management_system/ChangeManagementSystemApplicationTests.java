package com.example.change_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChangeManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
